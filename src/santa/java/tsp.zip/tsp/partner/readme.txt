/**********************************************************************
 *  readme template                                                   
 *  TSP Heuristics
 **********************************************************************/

Name:
Login:
Precept:

Partner's name (if any):
Partner's login:
Partner's precept:

Which partner is submitting the program files?

/**********************************************************************
 *  If you and/or your partner did the extra credit,  
 *  please note here who did it (only you, only your partner, both).
 **********************************************************************/




/**********************************************************************
 *  If you did the extra credit, explain your heuristic, and how
 *  you went about implementing it.
 **********************************************************************/




/**********************************************************************
 *  Enter any other comments that you have about this assignment.
 **********************************************************************/

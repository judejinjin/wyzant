/**************************************************************************
 *** COS 126 ***  Atomic Nature of Matter -- Final Project  **  Readme  ***
 **************************************************************************/

Name:
Login:
Precept:

Partner's name (if any):
Partner's login:
Partner's precept:

Which partner is submitting the program files?

Hours to complete assignment (optional):


/**************************************************************************
 *  The input size N for BeadTracker is the product of the number of      *
 *  pixels per frame and the number of frames. What is the estimated      *
 *  running time (in seconds) of BeadTracker as a function of N? Justify  *
 *  your answer with empirical data and explain how you used it. Your     *
 *  answer should be of the form a*N^b where b is an integer.             *
 **************************************************************************/



/**************************************************************************
 *  Did you receive help from classmates, past COS 126 students, or       *
 *  anyone else?  Please list their names.  ("A Sunday lab TA" or         *
 *  "Office hours on Thursday" is ok if you don't know their name.)       *
 **************************************************************************/



/**************************************************************************
 *  Describe any serious problems you encountered.                        *
 **************************************************************************/



/**************************************************************************
 *  List any other comments here.                                         *
 **************************************************************************/



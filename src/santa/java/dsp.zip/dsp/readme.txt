/**********************************************************************
 *  readme.txt template                                                   
 *  Digital Signal Processing
 **********************************************************************/

Name:
Partner (if any):
Partner's email:
Partner's precept:
Login:
Precept:
Hours to complete assignment (optional):



/**********************************************************************
 *  Explain your method for applying the echo filter.
 **********************************************************************/



/**********************************************************************
 *  List whatever help (if any) that you received, and the names of
 *  any students with whom you collaborated.                          
 **********************************************************************/



/**********************************************************************
*  If you collaborated, explain how you split the work.
 **********************************************************************/


/**********************************************************************
*  If you collaborated, would you recommend partnering for     
*  future assignments? And explain why or why not.
*  
*  If you did not collaborate, is there anything that would have
*  made you choose otherwise.
 **********************************************************************/
 





/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/




/**********************************************************************
 *  List any other comments here. Feel free to provide any feedback   
 *  on how much you learned from doing the assignment, and whether    
 *  you enjoyed doing it.                                             
 **********************************************************************/

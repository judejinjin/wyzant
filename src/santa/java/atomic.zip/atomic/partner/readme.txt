/**********************************************************************
 * partner readme template                                                   
 * Atomic Nature of Matter
 **********************************************************************/

Name: 
Login: 
Precept: 

Partner's name (if any):
Partner's email:
Partner's precept:

Which partner is submitting the program files?

Hours to complete assignment (optional): 

/**********************************************************************
 *  Enter any comments that you have about this assignment.
 **********************************************************************/

file prog1 > prog1.file.output
file prog2 > prog2.file.output
file prog3 > prog3.file.output
file prog4 > prog4.file.output
file prog5 > prog5.file.output
file prog6 > prog6.file.output
strings prog1 > prog1.strings.output
strings prog2 > prog2.strings.output
strings prog3 > prog3.strings.output
strings prog4 > prog4.strings.output
strings prog5 > prog5.strings.output
strings prog6 > prog6.strings.output


